library(readxl)
library(ggplot2)
library(ggpubr)
library(magrittr)
library(GGally)

setwd("/Users/ranyinon/Documents/Noam/RESEARCH/Test Results/SEEDS/Corelations/")
results<-read_xlsx("Nutritional.Climate.30sites.xlsx")

###BETA-GLUCAN
ggplot(results,aes(x= reorder(GENOTYPE, -results$`BETA-GLUCAN`),y=results$`BETA-GLUCAN`,))+
  geom_bar(stat = "identity")+theme_bw()+
  theme(axis.text.x = element_text(angle = 90))+
  theme(panel.border = element_blank())+expand_limits(x=0)+
  ggtitle("Beta-Glucan in Wild vs. Cultivated Barley (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5)) + 
  scale_fill_manual(values = c("darkolivegreen3", "darkolivegreen1")) +
  labs(fill = "Group")+
  xlab("GENOTYPE")

###STARCH
ggplot(results,aes(x=reorder(GENOTYPE, -STARCH),y=STARCH))+
  geom_bar(stat = "identity")+theme_bw()+
  theme(axis.text.x = element_text(angle = 90))+
  theme(panel.border = element_blank())+expand_limits(x=0)+
  ggtitle("Starch in Wild Barley (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5)) + 
  scale_fill_manual(values = c("royalblue1", "royalblue4")) + 
  labs(fill = "Group")+
  xlab("GENOTYPE")

###PROTEIN
ggplot(results,aes(x=reorder(GENOTYPE,-PROTEIN),y=PROTEIN,fill=factor("Color")))+
  geom_bar(stat = "identity")+theme_bw()+
  theme(axis.text.x = element_text(angle = 90))+
  theme(panel.border = element_blank())+expand_limits(x=0)+
  ggtitle("Protein in Wild Barley (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5)) + 
  scale_fill_manual(values = c("firebrick2", "firebrick4"))+
  labs(fill = "Group")+
  xlab("GENOTYPE")

##################################Percipitation########################################
#Beta Glucan- ##NO CORRELATION
ggplot(data = results, aes(x=results$Precipitation,y=results$`BETA-GLUCAN`))+geom_point()+
  ggtitle("Beta-Glucan by Percipitation")+
  xlab("Percipitation (ml)")+ylab("Beta-Glucan (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$Precipitation,results$`BETA-GLUCAN`)

#Starch ####CORRELATION
ggplot(data = results, aes(x=results$Precipitation,y=results$STARCH))+geom_point()+
  ggtitle("Starch by Percipitation")+
  xlab("Percipitation (ml)")+ylab("Starch (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$Precipitation,results$STARCH)

#Protein
ggplot(data = results, aes(x=results$Precipitation,y=results$PROTEIN))+geom_point()+
  ggtitle("Protein by Percipitation")+
  xlab("Percipitation (ml)")+ylab("Protein (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$Precipitation,results$PROTEIN)

####################################Elevation##########################################
#Beta-Glucan
ggplot(data = results, aes(x=results$Elevation,y=results$`BETA-GLUCAN`))+geom_point()+
  ggtitle("Beta-Glucan by Percipitation")+
  xlab("Percipitation (ml)")+ylab("Beta-Glucan (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$Elevation,results$`BETA-GLUCAN`)

#Starch
ggplot(data = results, aes(x=results$Elevation,y=results$STARCH))+geom_point()+
  ggtitle("Starch by Percipitation")+
  xlab("Percipitation (ml)")+ylab("Starch (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$Elevation,results$STARCH)

#Protein
ggplot(data = results, aes(x=results$Elevation,y=results$PROTEIN))+geom_point()+
  ggtitle("Protein by Percipitation")+
  xlab("Percipitation (ml)")+ylab("Protein (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$Elevation,results$PROTEIN)

####################################Temp. December##########################################
#Beta-Glucan
ggplot(data = results, aes(x=results$December,y=results$`BETA-GLUCAN`))+geom_point()+
  ggtitle("Beta-Glucan by Temp. in December")+
  xlab("Temp. in December (C)")+ylab("Beta-Glucan (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$December,results$`BETA-GLUCAN`)

#Starch
ggplot(data = results, aes(x=results$December,y=results$STARCH))+geom_point()+
  ggtitle("Stach by Temp. in December")+
  xlab("Temp. in December (C)")+ylab("Starch (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$December,results$STARCH)

#Protein
ggplot(data = results, aes(x=results$December,y=results$PROTEIN))+geom_point()+
  ggtitle("Protein by Temp. in December")+
  xlab("Temp. in December (C)")+ylab("Protein (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$December,results$PROTEIN)

####################################Stach*Protein##########################################
ggplot(data = results, aes(x=results$PROTEIN,y=results$STARCH))+geom_point()+
  ggtitle("Protein *Starch")+
  xlab("Protein (mg/100gr)")+ylab("Starch (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$PROTEIN,results$STARCH)

####################################Stach*Beta-Glucan##########################################
ggplot(data = results, aes(x=results$`BETA-GLUCAN`,y=results$STARCH))+geom_point()+
  ggtitle("Beta-Glucan *Starch")+
  xlab("Beta-Glucan (mg/100gr)")+ylab("Starch (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$`BETA-GLUCAN`,results$STARCH)

####################################Protein*Beta-Glucan##########################################
ggplot(data = results, aes(x=results$`BETA-GLUCAN`,y=results$PROTEIN))+geom_point()+
  ggtitle("Beta-Glucan *Protein")+
  xlab("Beta-Glucan (mg/100gr)")+ylab("Protein (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$`BETA-GLUCAN`,results$PROTEIN)

####################################Protein*Y##########################################
ggplot(data = results, aes(x=results$y,y=results$PROTEIN))+geom_point()+
  ggtitle("Y*Protein")+
  xlab("Y (mg/100gr)")+ylab("Protein (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$y,results$PROTEIN)

####################################Starch*Y#############################################
ggplot(data = results, aes(x=results$y,y=results$STARCH))+geom_point()+
  ggtitle("Y*Starch")+
  xlab("Y (mg/100gr)")+ylab("Starch (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$y,results$STARCH)

####################################Beta-Glucan*Y#############################################
ggplot(data = results, aes(x=results$y,y=results$`BETA-GLUCAN`))+geom_point()+
  ggtitle("Y*Beta-Glucan")+
  xlab("Y (mg/100gr)")+ylab("Beta-Glucan (mg/100gr)")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_smooth(method = "lm")+stat_cor()
cor.test(results$y,results$`BETA-GLUCAN`)

####################################Corelograms#############################################
#Nutritional traits and geographic traits
ggpairs(data=results,columns = 2:11, title = "Nutritional Traits cor. Geo.", colours="blue")

#Nutritional traits and phenotype



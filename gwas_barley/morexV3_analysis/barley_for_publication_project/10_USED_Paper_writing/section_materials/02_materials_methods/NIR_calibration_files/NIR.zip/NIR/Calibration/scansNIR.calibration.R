##This script is to calculate the average of the calibration data of 30 samples. 
##Each sample was scanned 5 times. 
##After the average calculation I will compare those results to season 2020 results and the wet lab results.

library(readxl)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(reshape2)

Protein<-read.csv("/Users/ranyinon/Documents/Noam/RESEARCH/Analyses/NIR/NIR2020.vs.NIRcali/Nutrients/Protein.csv")

Protein.long<-melt(Protein, id.vars = "GI")

ggplot(Protein.long, aes(fill=variable, y=value, x=as.factor(GI))) + 
  geom_bar(position="dodge", stat="identity")

anova



### ALL RAW DATA of nut. values from NIR
##Boxplot by ecotyps
##ANOVA by nut value and site

library(dplyr)
library(readxl)
library(magrittr)
library(ggplot2)
library(GGally)
library(gridExtra)
library(ggpairs)

setwd("/Users/ranyinon/Documents/Noam/RESEARCH/Test Results/NIR/")
all.data<-read.csv("Documents/Noam/RESEARCH/Analyses/NIR/NIR device data/NIR_ALL_RAW_rescanned.csv")

sasha.data<-read.table("Documents/Noam/RESEARCH/Analyses/Phenotype Data 2020/Phenotype Tables/HS1200.v10.newnames.txt", header = T, sep = "\t")

sasha.data<-sasha.data %>%          #בוחרים את העמודות הרצויות
  select(Ta_gN:Awn_Length.cm.)

sasha.data<-sasha.data %>%    #להפוך לאותו סוג ערך
  mutate(GI=as.factor(GI))

all.data<-all.data %>% #שיהיה אותו השם  לעמודה הרצו
  rename(GI=SampleID)

new.data<-full_join(sasha.data,all.data,by="GI")      #איחוד טבלאות לפי הGI כשמאחדים טבלאות צריך שיהיה את אותו השם לעמודות ואותו קלאס של הנתונים
new.data<-new.data[1:1209,1:15]       #העפנו את העמודות שלא צריך

new.data<-new.data %>% 
  arrange(Ta_gN)  

###NORMALITY####
shapiro1<-ggplot(new.data.wildonly,aes(x=ProteinAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(new.data.wildonly$ProteinAsis.)
##pvalue=0.007271***   not normal

shapiro2<-ggplot(new.data.wildonly,aes(x=StarchAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(new.data.wildonly$StarchAsis.)
##pvalue= 0.4154     normal

shapiro3<-ggplot(new.data.wildonly,aes(x=BetaglucansAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(new.data.wildonly$BetaglucansAsis.)
##pvalue=2.2e-16***    not normal


shapiro4<-ggplot(new.data.wildonly,aes(x=FiberAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(new.data.wildonly$FiberAsis.)   
## pvalue=1.473e-07***   not normal

grid.arrange(shapiro1,shapiro2,shapiro3,shapiro4,nrow=2)

den1<-ggplot(new.data.wildonly, aes(x=StarchAsis.))+
  geom_density()

den2<-ggplot(new.data.wildonly, aes(x=ProteinAsis.))+
  geom_density()

den3<-ggplot(new.data.wildonly, aes(x=BetaglucansAsis.))+
  geom_density()

den4<-ggplot(new.data.wildonly, aes(x=FiberAsis.))+
  geom_density()

grid.arrange(den1,den2,den3,den4,nrow=2)

##new data only for wild
new.data.wildonly<-new.data %>% 
  filter(Block.x<=4)
new.data.wildonly<-new.data.wildonly %>%        #adding ecotyps in a new column to the data
  mutate(Ecotype=rep(c("North","Coast","Desert","HZ1","HZ2","HZ3"),each=200))

########################################boxplot showing 5 site, 4 rep.##########################

##changing Block.no from from numeric to character
new.data[, c(3)]<- sapply(new.data[, c(3)], as.character)


########################################PROTEIN##
p1<-new.data.wildonly %>% 
  filter(Site_no<6) %>% 
  ggplot(.,aes(x=Ta_gN,y=ProteinAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,24)

p2<-new.data.wildonly %>% 
  filter(Site_no>5 & Site_no <11) %>% 
  ggplot(.,aes(x=Ta_gN,y=ProteinAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,24)

p3<-new.data.wildonly %>% 
  filter(Site_no>10 & Site_no <16) %>% 
  ggplot(.,aes(x=Ta_gN,y=ProteinAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,24)


p4<-new.data.wildonly %>% 
  filter(Site_no>15 & Site_no <21) %>% 
  ggplot(.,aes(x=Ta_gN,y=ProteinAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,24)


p5<-new.data.wildonly %>% 
  filter(Site_no>20 & Site_no <26) %>% 
  ggplot(.,aes(x=Ta_gN,y=ProteinAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,24)

p6<-new.data.wildonly %>% 
  filter(Site_no>25) %>% 
  ggplot(.,aes(x=Ta_gN,y=ProteinAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,24)


##Grid puts all the graphs wanted in one frame. nrow is the number of rows in the frame.
grid.arrange(p1,p2,p3,p4,p5,p6,nrow=2)


########################################STARCH##

s1<-new.data.wildonly %>% 
  filter(Site_no<6) %>% 
  ggplot(.,aes(x=Ta_gN,y=StarchAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,50)

s2<-new.data.wildonly %>% 
  filter(Site_no>5 & Site_no <11) %>% 
  ggplot(.,aes(x=Ta_gN,y=StarchAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,50)

s3<-new.data.wildonly %>% 
  filter(Site_no>10 & Site_no <16) %>% 
  ggplot(.,aes(x=Ta_gN,y=StarchAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,50)

s4<-new.data.wildonly %>% 
  filter(Site_no>15 & Site_no <21) %>% 
  ggplot(.,aes(x=Ta_gN,y=StarchAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,50)

s5<-new.data.wildonly %>% 
  filter(Site_no>20 & Site_no <26) %>% 
  ggplot(.,aes(x=Ta_gN,y=StarchAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,50)

s6<-new.data.wildonly %>% 
  filter(Site_no>25) %>% 
  ggplot(.,aes(x=Ta_gN,y=StarchAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(10,50)

grid.arrange(s1,s2,s3,s4,s5,s6,nrow=2)

########################################BETA GLUCAN##
##Colored sites and colored blocks#

b1<-new.data.wildonly %>% 
  filter(Site_no<6) %>% 
  ggplot(.,aes(x=Ta_gN,y=BetaglucansAsis.,fill=as.factor(Site_no)))+
  geom_boxplot(show.legend = F)+
  geom_point(position=position_jitterdodge(jitter.width=0, dodge.width = 0.3),
             aes(color=factor(Block.x)), show.legend = T)+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  ylim(1,8.5)


b2<-new.data.wildonly %>% 
  filter(Site_no>5 & Site_no <11) %>% 
  ggplot(.,aes(x=Ta_gN,y=BetaglucansAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(0,10)

b3<-new.data.wildonly %>% 
  filter(Site_no>10 & Site_no <16) %>% 
  ggplot(.,aes(x=Ta_gN,y=BetaglucansAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(0,10)


b4<-new.data.wildonly %>% 
  filter(Site_no>15 & Site_no <21) %>% 
  ggplot(.,aes(x=Ta_gN,y=BetaglucansAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(0,10)

b5<-new.data.wildonly %>% 
  filter(Site_no>20 & Site_no <26) %>% 
  ggplot(.,aes(x=Ta_gN,y=BetaglucansAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(0,10)

b6<-new.data.wildonly %>% 
  filter(Site_no>25) %>% 
  ggplot(.,aes(x=Ta_gN,y=BetaglucansAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(0,10)

grid.arrange(b1,b2,b3,b4,b5,b6,nrow=2)

########################################FIBER##

f1<-new.data.wildonly %>% 
  filter(Site_no<6) %>% 
  ggplot(.,aes(x=Ta_gN,y=FiberAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(2,8)

f2<-new.data.wildonly %>% 
  filter(Site_no>5 & Site_no <11) %>% 
  ggplot(.,aes(x=Ta_gN,y=FiberAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(2,8)

f3<-new.data.wildonly %>% 
  filter(Site_no>10 & Site_no <16) %>% 
  ggplot(.,aes(x=Ta_gN,y=FiberAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(2,8)

f4<-new.data.wildonly %>% 
  filter(Site_no>15 & Site_no <21) %>% 
  ggplot(.,aes(x=Ta_gN,y=FiberAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(2,8)

f5<-new.data.wildonly %>% 
  filter(Site_no>20 & Site_no <26) %>% 
  ggplot(.,aes(x=Ta_gN,y=FiberAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(2,8)

f6<-new.data.wildonly %>% 
  filter(Site_no>25) %>% 
  ggplot(.,aes(x=Ta_gN,y=FiberAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("")+
  ylab("")+
  theme(legend.position = "none") +
  ylim(2,8)

grid.arrange(f1,f2,f3,f4,f5,f6,nrow=2)
###############################################################################################




######################Significance between average of 4 rep. between genotypes#############################

##Anova to see the difference between averages of groups
##average of 4 rep. between genotypes in this case
##aov anova-see differences between genotypes


########PROTEIN#####

site1<-new.data.wildonly %>% 
  filter(Site_no==1)
site1.aov<-aov(site1$ProteinAsis.~site1$Ta_gN)
summary(site1.aov)
##Pvalue=0.000253 ***
##the differences between genotypes is larger than in the 4 rep.

site2<-new.data.wildonly %>% 
  filter(Site_no==2)
site2.aov<-aov(site2$ProteinAsis.~site2$Ta_gN)
summary(site2.aov)
##Pvalue=0.712

site3<-new.data.wildonly %>% 
  filter(Site_no==3)
site3.aov<-aov(site3$ProteinAsis.~site3$Ta_gN)
summary(site3.aov)
##Pvalue=0.0528

site4<-new.data.wildonly %>% 
  filter(Site_no==4)
site4.aov<-aov(site4$ProteinAsis.~site4$Ta_gN)
summary(site4.aov)
##Pvalue=0.152

site5<-new.data.wildonly %>% 
  filter(Site_no==5)  
site5.aov<-aov(site5$ProteinAsis.~site5$Ta_gN)
summary(site5.aov)
##Pvalue=0.591

site6<-new.data.wildonly %>% 
  filter(Site_no==6)
site6.aov<-aov(site6$ProteinAsis.~site6$Ta_gN)
summary(site6.aov)
##Pvalue=0.0842

site7<-new.data.wildonly %>% 
  filter(Site_no==7)
site7.aov<-aov(site7$ProteinAsis.~site7$Ta_gN)
summary(site7.aov)
##Pvalue=0.592


site8<-new.data.wildonly %>% 
  filter(Site_no==8)
site8.aov<-aov(site8$ProteinAsis.~site8$Ta_gN)
summary(site8.aov)
##Pvalue=3.86e-05 ***

site9<-new.data.wildonly %>% 
  filter(Site_no==9)
site9.aov<-aov(site9$ProteinAsis.~site9$Ta_gN)
summary(site9.aov)
##Pvalue=0.269

site10<-new.data.wildonly %>% 
  filter(Site_no==10)
site10.aov<-aov(site10$ProteinAsis.~site10$Ta_gN)
summary(site10.aov)
##Pvalue=0.104

site11<-new.data.wildonly %>% 
  filter(Site_no==11)
site11.aov<-aov(site11$ProteinAsis.~site11$Ta_gN)
summary(site11.aov)
##Pvalue=0.121

site12<-new.data.wildonly %>% 
  filter(Site_no==12)
site12.aov<-aov(site12$ProteinAsis.~site12$Ta_gN)
summary(site12.aov)
##Pvalue=0.891


site13<-new.data.wildonly %>% 
  filter(Site_no==13)
site13.aov<-aov(site13$ProteinAsis.~site13$Ta_gN)
summary(site13.aov)
##Pvalue=0.00188 **

site14<-new.data.wildonly %>% 
  filter(Site_no==14)
site14.aov<-aov(site14$ProteinAsis.~site14$Ta_gN)
summary(site14.aov)
##Pvalue=0.0709

site15<-new.data.wildonly %>% 
  filter(Site_no==15)
site15.aov<-aov(site15$ProteinAsis.~site15$Ta_gN)
summary(site15.aov)
##Pvalue=0.362


site16<-new.data.wildonly %>% 
  filter(Site_no==16)
site16.aov<-aov(site16$ProteinAsis.~site16$Ta_gN)
summary(site16.aov)
##Pvalue=0.033 *

site17<-new.data.wildonly %>% 
  filter(Site_no==17)
site17.aov<-aov(site17$ProteinAsis.~site17$Ta_gN)
summary(site17.aov)
##Pvalue=0.886

site18<-new.data.wildonly %>% 
  filter(Site_no==18)
site18.aov<-aov(site18$ProteinAsis.~site18$Ta_gN)
summary(site18.aov)
##Pvalue=0.0331 *

site19<-new.data.wildonly %>% 
  filter(Site_no==19)
site19.aov<-aov(site19$ProteinAsis.~site19$Ta_gN)
summary(site19.aov)
##Pvalue=0.109

site20<-new.data.wildonly %>% 
  filter(Site_no==20)
site20.aov<-aov(site20$ProteinAsis.~site20$Ta_gN)
summary(site20.aov)
##Pvalue=0.0404 *

site21<-new.data.wildonly %>% 
  filter(Site_no==21)
site21.aov<-aov(site21$ProteinAsis.~site21$Ta_gN)
summary(site21.aov)
##Pvalue=4.6e-05 ***

site22<-new.data.wildonly %>% 
  filter(Site_no==22)
site22.aov<-aov(site22$ProteinAsis.~site22$Ta_gN)
summary(site22.aov)
##Pvalue=0.0217 *

site23<-new.data.wildonly %>% 
  filter(Site_no==23)
site23.aov<-aov(site23$ProteinAsis.~site23$Ta_gN)
summary(site23.aov)
##Pvalue=0.547

site24<-new.data.wildonly %>% 
  filter(Site_no==24)
site24.aov<-aov(site24$ProteinAsis.~site24$Ta_gN)
summary(site24.aov)
##Pvalue=0.0497 *

site25<-new.data.wildonly %>% 
  filter(Site_no==25)
site25.aov<-aov(site25$ProteinAsis.~site25$Ta_gN)
summary(site25.aov)
##Pvalue=0.0382 *

site26<-new.data.wildonly %>% 
  filter(Site_no==26)
site26.aov<-aov(site26$ProteinAsis.~site26$Ta_gN)
summary(site26.aov)
##Pvalue=0.616

site27<-new.data.wildonly %>% 
  filter(Site_no==27)
site27.aov<-aov(site27$ProteinAsis.~site27$Ta_gN)
summary(site27.aov)
##Pvalue=0.626

site28<-new.data.wildonly %>% 
  filter(Site_no==28)
site28.aov<-aov(site28$ProteinAsis.~site28$Ta_gN)
summary(site28.aov)
##Pvalue=0.233

site29<-new.data.wildonly %>% 
  filter(Site_no==29)
site29.aov<-aov(site29$ProteinAsis.~site29$Ta_gN)
summary(site29.aov)
##Pvalue=0.0219 *

site30<-new.data.wildonly %>% 
  filter(Site_no==30)
site30.aov<-aov(site30$ProteinAsis.~site30$Ta_gN)
summary(site30.aov)
##Pvalue=3.42e-05 ***

########STARCH#####

site1<-new.data.wildonly %>% 
  filter(Site_no==1)
site1.aov<-aov(site1$StarchAsis.~site1$Ta_gN)
summary(site1.aov)
##Pvalue=0.205

site2<-new.data.wildonly %>% 
  filter(Site_no==2)
site2.aov<-aov(site2$StarchAsis.~site2$Ta_gN)
summary(site2.aov)
##Pvalue=0.000224 ***

site3<-new.data.wildonly %>% 
  filter(Site_no==3)
site3.aov<-aov(site3$StarchAsis.~site3$Ta_gN)
summary(site3.aov)
##Pvalue=0.0285 *

site4<-new.data.wildonly %>% 
  filter(Site_no==4)
site4.aov<-aov(site4$StarchAsis.~site4$Ta_gN)
summary(site4.aov)
##Pvalue=0.000297 ***

site5<-new.data.wildonly %>% 
  filter(Site_no==5)  
site5.aov<-aov(site5$StarchAsis.~site5$Ta_gN)
summary(site5.aov)
##Pvalue=0.115

site6<-new.data.wildonly %>% 
  filter(Site_no==6)
site6.aov<-aov(site6$StarchAsis.~site6$Ta_gN)
summary(site6.aov)
##Pvalue=0.557

site7<-new.data.wildonly %>% 
  filter(Site_no==7)
site7.aov<-aov(site7$StarchAsis.~site7$Ta_gN)
summary(site7.aov)
##Pvalue=0.15


site8<-new.data.wildonly %>% 
  filter(Site_no==8)
site8.aov<-aov(site8$StarchAsis.~site8$Ta_gN)
summary(site8.aov)
##Pvalue=0.0379 *

site9<-new.data.wildonly %>% 
  filter(Site_no==9)
site9.aov<-aov(site9$StarchAsis.~site9$Ta_gN)
summary(site9.aov)
##Pvalue=0.0466 *

site10<-new.data.wildonly %>% 
  filter(Site_no==10)
site10.aov<-aov(site10$StarchAsis.~site10$Ta_gN)
summary(site10.aov)
##Pvalue=0.285

site11<-new.data.wildonly %>% 
  filter(Site_no==11)
site11.aov<-aov(site11$StarchAsis.~site11$Ta_gN)
summary(site11.aov)
##Pvalue=0.634

site12<-new.data.wildonly %>% 
  filter(Site_no==12)
site12.aov<-aov(site12$StarchAsis.~site12$Ta_gN)
summary(site12.aov)
##Pvalue=0.922


site13<-new.data.wildonly %>% 
  filter(Site_no==13)
site13.aov<-aov(site13$StarchAsis.~site13$Ta_gN)
summary(site13.aov)
##Pvalue=0.000116 ***

site14<-new.data.wildonly %>% 
  filter(Site_no==14)
site14.aov<-aov(site14$StarchAsis.~site14$Ta_gN)
summary(site14.aov)
##Pvalue=0.986

site15<-new.data.wildonly %>% 
  filter(Site_no==15)
site15.aov<-aov(site15$StarchAsis.~site15$Ta_gN)
summary(site15.aov)
##Pvalue=8e-06 ***


site16<-new.data.wildonly %>% 
  filter(Site_no==16)
site16.aov<-aov(site16$StarchAsis.~site16$Ta_gN)
summary(site16.aov)
##Pvalue= 0.133

site17<-new.data.wildonly %>% 
  filter(Site_no==17)
site17.aov<-aov(site17$StarchAsis.~site17$Ta_gN)
summary(site17.aov)
##Pvalue=0.536

site18<-new.data.wildonly %>% 
  filter(Site_no==18)
site18.aov<-aov(site18$StarchAsis.~site18$Ta_gN)
summary(site18.aov)
##Pvalue=0.497

site19<-new.data.wildonly %>% 
  filter(Site_no==19)
site19.aov<-aov(site19$StarchAsis.~site19$Ta_gN)
summary(site19.aov)
##Pvalue=0.859

site20<-new.data.wildonly %>% 
  filter(Site_no==20)
site20.aov<-aov(site20$StarchAsis.~site20$Ta_gN)
summary(site20.aov)
##Pvalue=0.486

site21<-new.data.wildonly %>% 
  filter(Site_no==21)
site21.aov<-aov(site21$StarchAsis.~site21$Ta_gN)
summary(site21.aov)
##Pvalue=0.00193 **

site22<-new.data.wildonly %>% 
  filter(Site_no==22)
site22.aov<-aov(site22$StarchAsis.~site22$Ta_gN)
summary(site22.aov)
##Pvalue=0.418

site23<-new.data.wildonly %>% 
  filter(Site_no==23)
site23.aov<-aov(site23$StarchAsis.~site23$Ta_gN)
summary(site23.aov)
##Pvalue=0.00131 **

site24<-new.data.wildonly %>% 
  filter(Site_no==24)
site24.aov<-aov(site24$StarchAsis.~site24$Ta_gN)
summary(site24.aov)
##Pvalue=0.089

site25<-new.data.wildonly %>% 
  filter(Site_no==25)
site25.aov<-aov(site25$StarchAsis.~site25$Ta_gN)
summary(site25.aov)
##Pvalue=0.0017 **

site26<-new.data.wildonly %>% 
  filter(Site_no==26)
site26.aov<-aov(site26$StarchAsis.~site26$Ta_gN)
summary(site26.aov)
##Pvalue=0.251

site27<-new.data.wildonly %>% 
  filter(Site_no==27)
site27.aov<-aov(site27$StarchAsis.~site27$Ta_gN)
summary(site27.aov)
##Pvalue=0.00982 **

site28<-new.data.wildonly %>% 
  filter(Site_no==28)
site28.aov<-aov(site28$StarchAsis.~site28$Ta_gN)
summary(site28.aov)
##Pvalue=0.756

site29<-new.data.wildonly %>% 
  filter(Site_no==29)
site29.aov<-aov(site29$StarchAsis.~site29$Ta_gN)
summary(site29.aov)
##Pvalue=0.00556 **

site30<-new.data.wildonly %>% 
  filter(Site_no==30)
site30.aov<-aov(site30$StarchAsis.~site30$Ta_gN)
summary(site30.aov)
##Pvalue=0.811

########BETAGLUCAN#####

site1<-new.data.wildonly %>% 
  filter(Site_no==1)
site1.aov<-aov(site1$BetaglucansAsis.~site1$Ta_gN)
summary(site1.aov)
##Pvalue=0.179

site2<-new.data.wildonly %>% 
  filter(Site_no==2)
site2.aov<-aov(site2$BetaglucansAsis.~site2$Ta_gN)
summary(site2.aov)
##Pvalue=0.779

site3<-new.data.wildonly %>% 
  filter(Site_no==3)
site3.aov<-aov(site3$BetaglucansAsis.~site3$Ta_gN)
summary(site3.aov)
##Pvalue= 0.8

site4<-new.data.wildonly %>% 
  filter(Site_no==4)
site4.aov<-aov(site4$BetaglucansAsis.~site4$Ta_gN)
summary(site4.aov)
##Pvalue=0.227

site5<-new.data.wildonly %>% 
  filter(Site_no==5)  
site5.aov<-aov(site5$BetaglucansAsis.~site5$Ta_gN)
summary(site5.aov)
##Pvalue=0.35

site6<-new.data.wildonly %>% 
  filter(Site_no==6)
site6.aov<-aov(site6$BetaglucansAsis.~site6$Ta_gN)
summary(site6.aov)
##Pvalue=0.244

site7<-new.data.wildonly %>% 
  filter(Site_no==7)
site7.aov<-aov(site7$BetaglucansAsis.~site7$Ta_gN)
summary(site7.aov)
##Pvalue=0.988


site8<-new.data.wildonly %>% 
  filter(Site_no==8)
site8.aov<-aov(site8$BetaglucansAsis.~site8$Ta_gN)
summary(site8.aov)
##Pvalue=0.648

site9<-new.data.wildonly %>% 
  filter(Site_no==9)
site9.aov<-aov(site9$BetaglucansAsis.~site9$Ta_gN)
summary(site9.aov)
##Pvalue=0.384

site10<-new.data.wildonly %>% 
  filter(Site_no==10)
site10.aov<-aov(site10$BetaglucansAsis.~site10$Ta_gN)
summary(site10.aov)
##Pvalue=0.91

site11<-new.data.wildonly %>% 
  filter(Site_no==11)
site11.aov<-aov(site11$BetaglucansAsis.~site11$Ta_gN)
summary(site11.aov)
##Pvalue=0.821

site12<-new.data.wildonly %>% 
  filter(Site_no==12)
site12.aov<-aov(site12$BetaglucansAsis.~site12$Ta_gN)
summary(site12.aov)
##Pvalue=0.905


site13<-new.data.wildonly %>% 
  filter(Site_no==13)
site13.aov<-aov(site13$BetaglucansAsis.~site13$Ta_gN)
summary(site13.aov)
##Pvalue=0.383

site14<-new.data.wildonly %>% 
  filter(Site_no==14)
site14.aov<-aov(site14$BetaglucansAsis.~site14$Ta_gN)
summary(site14.aov)
##Pvalue=0.791

site15<-new.data.wildonly %>% 
  filter(Site_no==15)
site15.aov<-aov(site15$BetaglucansAsis.~site15$Ta_gN)
summary(site15.aov)
##Pvalue=0.0166 *


site16<-new.data.wildonly %>% 
  filter(Site_no==16)
site16.aov<-aov(site16$BetaglucansAsis.~site16$Ta_gN)
summary(site16.aov)
##Pvalue= 0.944

site17<-new.data.wildonly %>% 
  filter(Site_no==17)
site17.aov<-aov(site17$BetaglucansAsis.~site17$Ta_gN)
summary(site17.aov)
##Pvalue=0.599

site18<-new.data.wildonly %>% 
  filter(Site_no==18)
site18.aov<-aov(site18$BetaglucansAsis.~site18$Ta_gN)
summary(site18.aov)
##Pvalue=0.189

site19<-new.data.wildonly %>% 
  filter(Site_no==19)
site19.aov<-aov(site19$BetaglucansAsis.~site19$Ta_gN)
summary(site19.aov)
##Pvalue=0.075

site20<-new.data.wildonly %>% 
  filter(Site_no==20)
site20.aov<-aov(site20$BetaglucansAsis.~site20$Ta_gN)
summary(site20.aov)
##Pvalue=0.755

site21<-new.data.wildonly %>% 
  filter(Site_no==21)
site21.aov<-aov(site21$BetaglucansAsis.~site21$Ta_gN)
summary(site21.aov)
##Pvalue=0.131

site22<-new.data.wildonly %>% 
  filter(Site_no==22)
site22.aov<-aov(site22$BetaglucansAsis.~site22$Ta_gN)
summary(site22.aov)
##Pvalue=0.95

site23<-new.data.wildonly %>% 
  filter(Site_no==23)
site23.aov<-aov(site23$BetaglucansAsis.~site23$Ta_gN)
summary(site23.aov)
##Pvalue=0.971

site24<-new.data.wildonly %>% 
  filter(Site_no==24)
site24.aov<-aov(site24$BetaglucansAsis.~site24$Ta_gN)
summary(site24.aov)
##Pvalue=0.875

site25<-new.data.wildonly %>% 
  filter(Site_no==25)
site25.aov<-aov(site25$BetaglucansAsis.~site25$Ta_gN)
summary(site25.aov)
##Pvalue=0.847

site26<-new.data.wildonly %>% 
  filter(Site_no==26)
site26.aov<-aov(site26$BetaglucansAsis.~site26$Ta_gN)
summary(site26.aov)
##Pvalue=0.586

site27<-new.data.wildonly %>% 
  filter(Site_no==27)
site27.aov<-aov(site27$BetaglucansAsis.~site27$Ta_gN)
summary(site27.aov)
##Pvalue= 0.971

site28<-new.data.wildonly %>% 
  filter(Site_no==28)
site28.aov<-aov(site28$BetaglucansAsis.~site28$Ta_gN)
summary(site28.aov)
##Pvalue=0.983

site29<-new.data.wildonly %>% 
  filter(Site_no==29)
site29.aov<-aov(site29$BetaglucansAsis.~site29$Ta_gN)
summary(site29.aov)
##Pvalue=0.989

site30<-new.data.wildonly %>% 
  filter(Site_no==30)
site30.aov<-aov(site30$BetaglucansAsis.~site30$Ta_gN)
summary(site30.aov)
##Pvalue=0.0295 *

########FIBER#####

site1<-new.data.wildonly %>% 
  filter(Site_no==1)
site1.aov<-aov(site1$FiberAsis.~site1$Ta_gN)
summary(site1.aov)
##Pvalue=0.957

site2<-new.data.wildonly %>% 
  filter(Site_no==2)
site2.aov<-aov(site2$FiberAsis.~site2$Ta_gN)
summary(site2.aov)
##Pvalue=0.233

site3<-new.data.wildonly %>% 
  filter(Site_no==3)
site3.aov<-aov(site3$FiberAsis.~site3$Ta_gN)
summary(site3.aov)
##Pvalue= 0.269

site4<-new.data.wildonly %>% 
  filter(Site_no==4)
site4.aov<-aov(site4$FiberAsis.~site4$Ta_gN)
summary(site4.aov)
##Pvalue=0.292

site5<-new.data.wildonly %>% 
  filter(Site_no==5)  
site5.aov<-aov(site5$FiberAsis.~site5$Ta_gN)
summary(site5.aov)
##Pvalue=0.357

site6<-new.data.wildonly %>% 
  filter(Site_no==6)
site6.aov<-aov(site6$FiberAsis.~site6$Ta_gN)
summary(site6.aov)
##Pvalue=0.972

site7<-new.data.wildonly %>% 
  filter(Site_no==7)
site7.aov<-aov(site7$FiberAsis.~site7$Ta_gN)
summary(site7.aov)
##Pvalue=0.562


site8<-new.data.wildonly %>% 
  filter(Site_no==8)
site8.aov<-aov(site8$FiberAsis.~site8$Ta_gN)
summary(site8.aov)
##Pvalue=0.903

site9<-new.data.wildonly %>% 
  filter(Site_no==9)
site9.aov<-aov(site9$FiberAsis.~site9$Ta_gN)
summary(site9.aov)
##Pvalue=0.253

site10<-new.data.wildonly %>% 
  filter(Site_no==10)
site10.aov<-aov(site10$FiberAsis.~site10$Ta_gN)
summary(site10.aov)
##Pvalue=0.85

site11<-new.data.wildonly %>% 
  filter(Site_no==11)
site11.aov<-aov(site11$FiberAsis.~site11$Ta_gN)
summary(site11.aov)
##Pvalue=0.877

site12<-new.data.wildonly %>% 
  filter(Site_no==12)
site12.aov<-aov(site12$FiberAsis.~site12$Ta_gN)
summary(site12.aov)
##Pvalue=0.801


site13<-new.data.wildonly %>% 
  filter(Site_no==13)
site13.aov<-aov(site13$FiberAsis.~site13$Ta_gN)
summary(site13.aov)
##Pvalue=0.0213 *

site14<-new.data.wildonly %>% 
  filter(Site_no==14)
site14.aov<-aov(site14$FiberAsis.~site14$Ta_gN)
summary(site14.aov)
##Pvalue=0.899

site15<-new.data.wildonly %>% 
  filter(Site_no==15)
site15.aov<-aov(site15$FiberAsis.~site15$Ta_gN)
summary(site15.aov)
##Pvalue=0.0142 *


site16<-new.data.wildonly %>% 
  filter(Site_no==16)
site16.aov<-aov(site16$FiberAsis.~site16$Ta_gN)
summary(site16.aov)
##Pvalue= 0.929

site17<-new.data.wildonly %>% 
  filter(Site_no==17)
site17.aov<-aov(site17$FiberAsis.~site17$Ta_gN)
summary(site17.aov)
##Pvalue=0.929

site18<-new.data.wildonly %>% 
  filter(Site_no==18)
site18.aov<-aov(site18$FiberAsis.~site18$Ta_gN)
summary(site18.aov)
##Pvalue=0.67

site19<-new.data.wildonly %>% 
  filter(Site_no==19)
site19.aov<-aov(site19$FiberAsis.~site19$Ta_gN)
summary(site19.aov)
##Pvalue=0.49

site20<-new.data.wildonly %>% 
  filter(Site_no==20)
site20.aov<-aov(site20$FiberAsis.~site20$Ta_gN)
summary(site20.aov)
##Pvalue=0.805

site21<-new.data.wildonly %>% 
  filter(Site_no==21)
site21.aov<-aov(site21$FiberAsis.~site21$Ta_gN)
summary(site21.aov)
##Pvalue=0.0922

site22<-new.data.wildonly %>% 
  filter(Site_no==22)
site22.aov<-aov(site22$FiberAsis.~site22$Ta_gN)
summary(site22.aov)
##Pvalue=0.52

site23<-new.data.wildonly %>% 
  filter(Site_no==23)
site23.aov<-aov(site23$FiberAsis.~site23$Ta_gN)
summary(site23.aov)
##Pvalue=7.18e-05 ***

site24<-new.data.wildonly %>% 
  filter(Site_no==24)
site24.aov<-aov(site24$FiberAsis.~site24$Ta_gN)
summary(site24.aov)
##Pvalue=0.906

site25<-new.data.wildonly %>% 
  filter(Site_no==25)
site25.aov<-aov(site25$FiberAsis.~site25$Ta_gN)
summary(site25.aov)
##Pvalue=0.14

site26<-new.data.wildonly %>% 
  filter(Site_no==26)
site26.aov<-aov(site26$FiberAsis.~site26$Ta_gN)
summary(site26.aov)
##Pvalue=0.754

site27<-new.data.wildonly %>% 
  filter(Site_no==27)
site27.aov<-aov(site27$FiberAsis.~site27$Ta_gN)
summary(site27.aov)
##Pvalue= 0.0504 .

site28<-new.data.wildonly %>% 
  filter(Site_no==28)
site28.aov<-aov(site28$FiberAsis.~site28$Ta_gN)
summary(site28.aov)
##Pvalue=0.597

site29<-new.data.wildonly %>% 
  filter(Site_no==29)
site29.aov<-aov(site29$FiberAsis.~site29$Ta_gN)
summary(site29.aov)
##Pvalue=0.14

site30<-new.data.wildonly %>% 
  filter(Site_no==30)
site30.aov<-aov(site30$FiberAsis.~site30$Ta_gN)
summary(site30.aov)
##Pvalue= 0.94

###############################################################################################






##############Median calculations of each nut value by sites######################

##to calculate avr/median 
medians.all<-new.data.wildonly %>% 
  group_by(Ta_gN) %>% 
  summarise(across(where(is.numeric),median,na.rm=T))     ##calculates median between 4 rep. gives 300 genptypes
##i can now calculate this by ecotypes like i did above with the boxplot for protein. 
##i need to add a new column for the ecotypes in order to see the boxplots

ggplot(medians.all,aes(x=FiberAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(medians.all$FiberAsis.)
##p-value = 0.02055

ggplot(medians.all,aes(x=ProteinAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(medians.all$ProteinAsis.)
##p-value = 0.6008

ggplot(medians.all,aes(x=StarchAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(medians.all$StarchAsis.)
##p-value = 0.09199

ggplot(medians.all,aes(x=BetaglucansAsis.)) + geom_histogram(binwidth = 0.3)
shapiro.test(medians.all$BetaglucansAsis.)
##p-value = 0.0001152


##CORRELATION  between elevation and and Nutri values of average of all genotypes per site.
elevation<-new.data.wildonly %>% 
  group_by(Site_no) %>% 
  summarise(across(where(is.numeric),median,na.rm=T))

setwd("/Users/ranyinon/Documents/Noam/RESEARCH/Phenotype Data 2020/")
elev.bar<-read_xls("SitesClimateData.xls")

elevation$elev <- elev.bar$Elevation


##after calculating medians for all phenotyps, I made a boxplot showing each box is a 
##different site. this shows the difference between site (for protein)
medians.all %>% 
  ggplot(.,aes(x=Site_no,y=ProteinAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("Site No.")+
  ylab("Protein %")+
  theme(legend.position = "none") +
  ylim(10,24)

medians.all %>% 
  ggplot(.,aes(x=Site_no,y=StarchAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("Site No.")+
  ylab("Starch %")+
  theme(legend.position = "none") +
  ylim(10,50)


medians.all %>% 
  ggplot(.,aes(x=Site_no,y=FiberAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("Site No.")+
  ylab("Fiber %")+
  theme(legend.position = "none") +
  ylim(3,7)

medians.all %>% 
  ggplot(.,aes(x=Site_no,y=BetaglucansAsis.,fill=as.factor(Site_no)))+
  geom_boxplot()+
  geom_point()+
  theme(axis.text.x = element_text(angle = 90))+
  xlab("Site No.")+
  ylab("Beta-Glucan %")+
  theme(legend.position = "none") +
  ylim(2,10)


grain.weight<-read_xlsx("Spontaneum_Phenotype_2020_2.5_updated.xlsx")

grain.weight<- grain.weight %>%          #בוחרים את העמודות הרצויות
  select(TagN:Awn_Length.cm.)

grain.weight.median<-grain.weight %>% 
  group_by(TagN) %>% 
  summarise(across(where(is.numeric),median,na.rm=T))

##I am now adding the grain weight median to the median.all table.
grain.weight.median$

####################CORRELATION#############################################

ggpairs(data=new.data.wildonly,columns = 12:15, title = "Nutritional Traits cor. Geo.", colours="blue")


##CORRELATION  between elevation and and Nutri values of average of all genotypes per site.
##Elevation is the new data with the elevation number and medians of each trait.
elevation<-new.data.wildonly %>% 
  group_by(Site_no) %>% 
  summarise(across(where(is.numeric),median,na.rm=T))

setwd("/Users/ranyinon/Documents/Noam/RESEARCH/Phenotype Data 2020/")
elev.bar<-read_xls("SitesClimateData.xls")

elevation$elev <- elev.bar$Elevation
elevation$cor.y <- elev.bar$y
elevation$ecotype<-as.factor(elev.bar$Polygon)

corystarch<-ggplot(data = elevation, aes(x=cor.y,y=StarchAsis., color= ecotype))+
  geom_point()+
  theme_classic()+
  ggtitle("Starch value by cordinates")+ #how to center
  theme(axis.text = element_text(size=12),
        plot.title = element_text(hjust = 0.5))+
  ylab("Starch %")+
  xlab("South ---> North")


coryprotein<-ggplot(data = elevation, aes(x=cor.y,y=ProteinAsis., color= ecotype))+
  geom_point()+
  theme_classic()+
  ggtitle("Protein value by cordinates")+ #how to center
  theme(plot.title = element_text(hjust = 0.5))+
  ylab("Protein%")+
  xlab("South ---> North")

corybetaglucans<-ggplot(data = elevation, aes(x=cor.y,y=BetaglucansAsis., color= ecotype))+
  geom_point()+
  theme_classic()+
  ggtitle("Betaglucans value by cordinates")+ 
  theme(plot.title = element_text(hjust = 0.5))+
  ylab("% Betaglucans")+
  xlab("South ---> North")

coryfiber<-ggplot(data = elevation, aes(x=cor.y,y=FiberAsis., color= ecotype))+
  geom_point()+
  theme_classic()+
  ggtitle("Fiber value by cordinates")+ 
  theme(plot.title = element_text(hjust = 0.5))+
  ylab("% Fiber")+
  xlab("South ---> North")

grid.arrange(corybetaglucans,coryprotein,coryfiber,corystarch, nrow=2)

GEOnNUT<- merge(elev.bar,elevation, by= "Number")
colnames(elevation)[1] <- "Number"
GEOnNUT[,30:33] <- NULL 

cor.test(new.data.wildonly$ProteinAsis., new.data.wildonly$StarchAsis.)
cor.test(GEOnNUT$ProteinAsis., GEOnNUT$Precipitation)
library(ggpubr)

beta.protein<-ggscatter(GEOnNUT, x = "ProteinAsis.", y = "BetaglucansAsis.", 
          add = "reg.line", conf.int = TRUE, color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Protein%", ylab = "BetaglucansAsis.")


ggscatter(GEOnNUT, x = "ProteinAsis.", y = "StarchAsis.", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "% Protein", ylab = "% Starch.")


ggscatter(GEOnNUT, x = "ProteinAsis.", y = "Precipitation", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Protein%", ylab = "Precipitation")

ggscatter(GEOnNUT, x = "ProteinAsis.", y = "Elevation", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Protein%", ylab = "Elevation")

ggscatter(GEOnNUT, x = "ProteinAsis.", y = "Organic_material", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Protein%", ylab = "Organic_material")

ggscatter(GEOnNUT, x = "StarchAsis.", y = "Precipitation", 
          add = "reg.line", conf.int = TRUE, color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Starch%", ylab = "Precipitation")

beta.y<-ggscatter(GEOnNUT, x = "BetaglucansAsis.", y = "y", 
          add = "reg.line", conf.int = TRUE,color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Betaglucan%", ylab = "cor.y")

ggscatter(GEOnNUT, x = "StarchAsis.", y = "March", 
          add = "reg.line", conf.int = TRUE,color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "starch%", ylab = "max temp")

maxtemp.starch<-ggscatter(GEOnNUT, x = "BetaglucansAsis.", y = "March", 
          add = "reg.line", conf.int = TRUE,color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Betaglucan%", ylab = "max temp")

ggscatter(GEOnNUT, x = "ProteinAsis.", y = "March", 
          add = "reg.line", conf.int = TRUE,color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Protein%", ylab = "max temp")

ggscatter(GEOnNUT, x = "ProteinAsis.", y = "March", 
          add = "reg.line", conf.int = TRUE,color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Protein%", ylab = "max temp")

ggscatter(GEOnNUT, x = "ProteinAsis.", y = "PH", 
          add = "reg.line", conf.int = TRUE,color = "Polygon",
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Protein%", ylab = "PH")

grid.arrange(maxtemp.starch,beta.y,beta.protein, nrow=2)

library(GGally)
ggpairs(data=GEOnNUT,columns = 7:29, title = "Nutritional Traits cor. Geo.", colours="blue")





